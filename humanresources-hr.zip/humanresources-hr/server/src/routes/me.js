import express from 'express'
import { pool } from '../db/pool.js'
import { authenticate, requirePermission } from '../middleware/auth.js'

const router = express.Router()

router.use(authenticate)

router.get('/', async (req, res, next) => {
  try {
    const userResult = await pool.query(
      `SELECT
        u.id, u.name, u.username, u.email, u.company_id,
        u.employee_id, ar.name AS access_role_name,
        ar.display_name AS access_role_display_name,
        e.name AS employee_name, e.status AS employee_status
       FROM users u
       LEFT JOIN access_roles ar ON ar.id = u.access_role_id
       LEFT JOIN employees e ON e.id = u.employee_id
       WHERE u.id = $1 AND u.company_id = $2`,
      [req.user.userId, req.user.companyId]
    )

    if (!userResult.rowCount) {
      return res.status(404).json({ message: 'Usuário não encontrado.' })
    }

    return res.json({
      user: userResult.rows[0],
      permissions: req.user.permissions || [],
      isAdmin: Boolean(req.user.isAdmin)
    })
  } catch (error) {
    return next(error)
  }
})



// Retorna somente os dados financeiros autorizados para a empresa da sessão.
// A tela não precisa da permissão ampla employees_view para listar funcionários
// necessários a uma rotina financeira autorizada.
router.get('/financial-data', async (req, res, next) => {
  const permissionModules = [
    { module: 'salaries', permission: ['finance_salary_view', 'finance_salary_manage'], keys: { salaryHistory: 'salaryHistory' } },
    { module: 'payroll', permission: ['finance_payroll_view', 'finance_payroll_manage'], keys: { payrolls: 'payrolls' } },
    { module: 'financial_events', permission: ['finance_events_view', 'finance_events_manage'], keys: { financialEvents: 'financialEvents' } },
    { module: 'financial_advanced', permission: ['finance_advanced_view', 'finance_advanced_manage'], keys: {
      financialVacations: 'financialVacations',
      financialThirteenths: 'financialThirteenths',
      financialTerminations: 'financialTerminations'
    } }
  ]

  const userPermissions = Array.isArray(req.user?.permissions) ? req.user.permissions : []
  const allowedModules = permissionModules.filter((item) =>
    req.user?.isAdmin === true || item.permission.some((permission) => userPermissions.includes(permission))
  )

  if (!allowedModules.length) {
    return res.status(403).json({ message: 'Você não tem permissão para acessar os dados financeiros.' })
  }

  try {
    const needsEmployees = allowedModules.some((item) =>
      ['salaries', 'payroll', 'financial_advanced'].includes(item.module)
    )
    const employeeResult = needsEmployees
      ? await pool.query(
          `SELECT e.id, e.name, e.status, e.admission_date, e.termination_date,
                  e.branch_id, e.department_id, e.role_id, e.position_id, e.registration_data,
                  b.name AS branch_name, d.name AS department_name, r.name AS role_name
           FROM employees e
           LEFT JOIN branches b ON b.id = e.branch_id AND b.company_id = e.company_id
           LEFT JOIN departments d ON d.id = e.department_id AND d.company_id = e.company_id
           LEFT JOIN roles r ON r.id = e.role_id AND r.company_id = e.company_id
           WHERE e.company_id = $1
           ORDER BY e.name`,
          [req.user.companyId]
        )
      : { rows: [] }

    const recordsResult = await pool.query(
      `SELECT module_key, record_key, payload
       FROM app_records
       WHERE company_id = $1
         AND module_key = ANY($2::text[])
         AND module_key NOT IN ('payroll', 'salaries', 'financial_events')
       ORDER BY updated_at DESC`,
      [req.user.companyId, allowedModules.map((item) => item.module)]
    )

    const records = {}
    for (const moduleConfig of allowedModules) {
      for (const responseKey of Object.keys(moduleConfig.keys)) {
        records[responseKey] = []
      }
    }

    for (const row of recordsResult.rows) {
      const moduleConfig = allowedModules.find((item) => item.module === row.module_key)
      if (!moduleConfig) continue
      const responseKey = Object.keys(moduleConfig.keys).find((key) => moduleConfig.keys[key] === row.record_key)
      if (responseKey) records[responseKey] = Array.isArray(row.payload) ? row.payload : []
    }

    const employees = employeeResult.rows.map((employee) => ({
      ...employee,
      active: employee.status === 'active',
      admissionDate: employee.admission_date ? String(employee.admission_date).slice(0, 10) : '',
      terminationDate: employee.termination_date ? String(employee.termination_date).slice(0, 10) : '',
      registration: employee.registration_data?.registration || employee.registration_data?.registrationNumber || '',
      branchId: employee.branch_id,
      departmentId: employee.department_id,
      roleId: employee.role_id,
      positionId: employee.position_id
    }))

    // Salários e eventos financeiros já possuem tabelas relacionais próprias.
    // Não use app_records como fonte oficial para esses dois catálogos.
    if (allowedModules.some((item) => item.module === 'salaries')) {
      const salaryResult = await pool.query(
        `SELECT external_id, employee_id, external_employee_id, employee_name,
                salary, effective_date, reason, notes, payload, created_at, updated_at
         FROM salary_history
         WHERE company_id = $1
         ORDER BY effective_date DESC, created_at DESC, external_id`,
        [req.user.companyId]
      )
      records.salaryHistory = salaryResult.rows.map((row) => {
        const legacy = row.payload && typeof row.payload === 'object' && !Array.isArray(row.payload)
          ? row.payload
          : {}
        return {
          ...legacy,
          id: String(row.external_id),
          employeeId: row.employee_id ? String(row.employee_id) : String(row.external_employee_id || legacy.employeeId || ''),
          employeeName: row.employee_name || legacy.employeeName || '',
          salary: Number(row.salary),
          effectiveDate: String(row.effective_date).slice(0, 10),
          reason: row.reason,
          notes: row.notes || '',
          createdAt: legacy.createdAt || row.created_at,
          createdBy: legacy.createdBy || '',
          ...(row.updated_at ? { updatedAt: row.updated_at } : {})
        }
      })
    }

    if (allowedModules.some((item) => item.module === 'financial_events')) {
      const financialEventsResult = await pool.query(
        `SELECT payload FROM financial_events
         WHERE company_id = $1
         ORDER BY lower(name), external_id`,
        [req.user.companyId]
      )
      records.financialEvents = financialEventsResult.rows.map(({ payload }) => payload)
    }

    if (allowedModules.some((item) => item.module === 'payroll')) {
      const payrollResult = await pool.query(
        `SELECT p.external_id, p.competence, p.status, p.data,
                p.created_at, p.updated_at,
                COALESCE(
                  jsonb_agg(
                    CASE WHEN pi.data = '{}'::jsonb THEN jsonb_build_object(
                      'employeeId', COALESCE(pi.external_employee_id, pi.employee_id::text, ''),
                      'baseSalary', pi.base_salary,
                      'earningsTotal', pi.earnings,
                      'totalDeductions', pi.deductions,
                      'inss', pi.inss,
                      'irrf', pi.irrf,
                      'fgts', pi.fgts,
                      'netSalary', pi.net_salary,
                      'overtimeMinutes', pi.overtime_minutes,
                      'overtimeAmount', pi.overtime_amount
                    ) ELSE pi.data END
                    ORDER BY pi.external_id
                  ) FILTER (WHERE pi.id IS NOT NULL),
                  '[]'::jsonb
                ) AS employee_items
         FROM payrolls p
         LEFT JOIN payroll_items pi ON pi.payroll_id = p.id
         WHERE p.company_id = $1
         GROUP BY p.id
         ORDER BY p.competence DESC, p.created_at DESC`,
        [req.user.companyId]
      )
      records.payrolls = payrollResult.rows.map((row) => {
        const data = row.data && typeof row.data === 'object' && !Array.isArray(row.data)
          ? row.data
          : {}
        const employeeItems = Array.isArray(row.employee_items) ? row.employee_items : []
        const updatedAt = row.updated_at instanceof Date
          ? row.updated_at.toISOString()
          : String(row.updated_at || data.updatedAt || '')
        const createdAt = row.created_at instanceof Date
          ? row.created_at.toISOString()
          : String(row.created_at || data.createdAt || '')
        return {
          ...data,
          id: String(row.external_id),
          competence: row.competence instanceof Date
            ? row.competence.toISOString().slice(0, 7)
            : String(row.competence || '').slice(0, 7),
          status: row.status === 'closed' ? 'closed' : 'draft',
          employees: employeeItems.length || !Array.isArray(data.employees)
            ? employeeItems
            : data.employees,
          createdAt,
          updatedAt
        }
      })
    }

    // Históricos legados podem conter o ID numérico usado antes da migração.
    // Normalizamos referências conhecidas para o UUID atual sem descartar
    // registros cujo vínculo não possa ser identificado com segurança.
    const employeeIdAliases = new Map()
    for (const employee of employees) {
      const registration = employee.registration_data && typeof employee.registration_data === 'object'
        ? employee.registration_data
        : {}
      for (const alias of [
        employee.id,
        registration.legacyId,
        registration.legacy_id,
        registration.idLegacy,
        registration.id
      ]) {
        if (alias !== null && alias !== undefined && String(alias).trim()) {
          employeeIdAliases.set(String(alias), String(employee.id))
        }
      }
    }

    for (const [key, value] of Object.entries(records)) {
      if (!Array.isArray(value)) continue
      records[key] = value.map((record) => {
        if (!record || typeof record !== 'object') return record

        // O funcionário da folha fica dentro de payroll.employees,
        // portanto precisa da mesma normalização de IDs legados usada
        // nos registros financeiros de nível superior.
        if (key === 'payrolls' && Array.isArray(record.employees)) {
          return {
            ...record,
            employees: record.employees.map((payrollEmployee) => {
              if (
                !payrollEmployee ||
                payrollEmployee.employeeId === undefined ||
                payrollEmployee.employeeId === null
              ) {
                return payrollEmployee
              }
              const canonicalEmployeeId = employeeIdAliases.get(
                String(payrollEmployee.employeeId)
              )
              return canonicalEmployeeId
                ? { ...payrollEmployee, employeeId: canonicalEmployeeId }
                : payrollEmployee
            })
          }
        }

        if (record.employeeId === undefined || record.employeeId === null) {
          return record
        }
        const canonicalEmployeeId = employeeIdAliases.get(String(record.employeeId))
        return canonicalEmployeeId ? { ...record, employeeId: canonicalEmployeeId } : record
      })
    }

    return res.json({ employees, ...records })
  } catch (error) {
    return next(error)
  }
})


// Atualiza somente os campos editáveis do próprio perfil.
// O ID e a empresa vêm do token autenticado, nunca do corpo da requisição.
router.patch('/profile', requirePermission('profile_edit'), async (req, res, next) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : ''
  const username = typeof req.body?.username === 'string' ? req.body.username.trim() : ''

  if (!name || !username) {
    return res.status(400).json({
      message: 'Nome e usuário são obrigatórios.'
    })
  }

  if (name.length > 120 || username.length > 80) {
    return res.status(400).json({
      message: 'Nome ou usuário excede o limite permitido.'
    })
  }

  try {
    const updatedResult = await pool.query(
      `UPDATE users
       SET name = $3, username = $4, updated_at = NOW()
       WHERE id = $1 AND company_id = $2 AND active = TRUE
       RETURNING id, name, username, email, company_id, employee_id`,
      [req.user.userId, req.user.companyId, name, username]
    )

    if (!updatedResult.rowCount) {
      return res.status(404).json({
        message: 'Usuário não encontrado ou inativo.'
      })
    }

    return res.json({
      user: updatedResult.rows[0],
      message: 'Perfil atualizado com sucesso.'
    })
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({
        message: 'Esse nome de usuário já está sendo utilizado nesta empresa.'
      })
    }

    return next(error)
  }
})


// Autoatendimento de ponto: retorna apenas os dados do funcionário vinculado
// ao token autenticado. Não aceita employeeId informado pelo cliente.
router.get('/timekeeping/today', async (req, res, next) => {
  if (!req.user?.employeeId) {
    return res.json({
      user: { employeeId: null },
      employee: null,
      record: null
    })
  }

  try {
    const employeeResult = await pool.query(
      `SELECT e.id, e.name, e.status, e.registration_data,
              p.name AS position_name
       FROM employees e
       LEFT JOIN positions p
         ON p.id = e.position_id AND p.company_id = e.company_id
       WHERE e.id = $1 AND e.company_id = $2`,
      [req.user.employeeId, req.user.companyId]
    )

    if (!employeeResult.rowCount) {
      return res.json({
        user: { employeeId: req.user.employeeId },
        employee: null,
        record: null
      })
    }

    const employeeRow = employeeResult.rows[0]
    const registrationData = employeeRow.registration_data || {}
    const employee = {
      id: employeeRow.id,
      name: employeeRow.name || registrationData.name || '',
      status: employeeRow.status || 'active',
      position: employeeRow.position_name || registrationData.position || registrationData.jobTitle || ''
    }

    const dateParts = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'America/Sao_Paulo',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).formatToParts(new Date())
    const datePart = (type) => dateParts.find((part) => part.type === type)?.value || ''
    const date = `${datePart('year')}-${datePart('month')}-${datePart('day')}`

    const recordsResult = await pool.query(
      `SELECT payload
       FROM app_records
       WHERE company_id = $1
         AND module_key IN ('timekeeping_clock', 'timekeeping')
         AND record_key = 'timeClockRecords'
       ORDER BY CASE WHEN module_key = 'timekeeping_clock' THEN 0 ELSE 1 END`,
      [req.user.companyId]
    )

    const aliases = new Set([
      String(employeeRow.id),
      registrationData.legacyId == null ? '' : String(registrationData.legacyId),
      registrationData.legacy_id == null ? '' : String(registrationData.legacy_id),
      registrationData.id == null ? '' : String(registrationData.id)
    ].filter(Boolean))

    let record = null
    for (const row of recordsResult.rows) {
      const records = Array.isArray(row.payload) ? row.payload : []
      record = records.find((item) =>
        aliases.has(String(item?.employeeId)) && String(item?.date) === date
      ) || record
      if (record) break
    }

    return res.json({
      user: { employeeId: employeeRow.id },
      employee,
      record
    })
  } catch (error) {
    return next(error)
  }
})

// Registra a próxima batida no servidor. O funcionário, a data e a hora
// são derivados da sessão/servidor; o cliente não pode escolher outro funcionário.
router.post('/timekeeping/punch', async (req, res, next) => {
  const permissions = Array.isArray(req.user?.permissions) ? req.user.permissions : []
  if (!req.user?.isAdmin && !permissions.includes('ponto_bater')) {
    return res.status(403).json({ message: 'Você não tem permissão para registrar o ponto.' })
  }

  if (!req.user?.employeeId) {
    return res.status(400).json({ message: 'Esta conta não está vinculada a um funcionário.' })
  }

  const source = ['remote', 'biometric'].includes(req.body?.source)
    ? req.body.source
    : 'remote'
  const locationInput = req.body?.location
  let location = null

  if (locationInput && typeof locationInput === 'object' && !Array.isArray(locationInput)) {
    location = {
      latitude: Number.isFinite(Number(locationInput.latitude)) ? Number(locationInput.latitude) : null,
      longitude: Number.isFinite(Number(locationInput.longitude)) ? Number(locationInput.longitude) : null,
      accuracy: Number.isFinite(Number(locationInput.accuracy)) ? Number(locationInput.accuracy) : null,
      address: typeof locationInput.address === 'string' ? locationInput.address.slice(0, 500) : null
    }
  }

  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    // Serializa atualizações da lista legada por empresa para evitar perda
    // de batidas simultâneas enquanto o módulo usa um payload JSONB agregado.
    await client.query(
      'SELECT pg_advisory_xact_lock(hashtext($1), hashtext($2))',
      [String(req.user.companyId), 'timekeeping_clock:timeClockRecords']
    )

    const employeeResult = await client.query(
      `SELECT id, registration_data
       FROM employees
       WHERE id = $1 AND company_id = $2 AND status = 'active'`,
      [req.user.employeeId, req.user.companyId]
    )
    if (!employeeResult.rowCount) {
      await client.query('ROLLBACK')
      return res.status(404).json({ message: 'Funcionário ativo não encontrado.' })
    }

    const employeeRow = employeeResult.rows[0]
    const registrationData = employeeRow.registration_data || {}
    const aliases = new Set([
      String(employeeRow.id),
      registrationData.legacyId == null ? '' : String(registrationData.legacyId),
      registrationData.legacy_id == null ? '' : String(registrationData.legacy_id),
      registrationData.id == null ? '' : String(registrationData.id)
    ].filter(Boolean))

    const dateParts = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'America/Sao_Paulo',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).formatToParts(new Date())
    const datePart = (type) => dateParts.find((part) => part.type === type)?.value || ''
    const date = `${datePart('year')}-${datePart('month')}-${datePart('day')}`
    const timeParts = new Intl.DateTimeFormat('en-GB', {
      timeZone: 'America/Sao_Paulo',
      hour: '2-digit',
      minute: '2-digit',
      hourCycle: 'h23'
    }).formatToParts(new Date())
    const time = `${timeParts.find((part) => part.type === 'hour')?.value || '00'}:${timeParts.find((part) => part.type === 'minute')?.value || '00'}`
    const now = new Date().toISOString()

    const currentResult = await client.query(
      `SELECT module_key, payload
       FROM app_records
       WHERE company_id = $1
         AND module_key IN ('timekeeping_clock', 'timekeeping')
         AND record_key = 'timeClockRecords'
       ORDER BY CASE WHEN module_key = 'timekeeping_clock' THEN 0 ELSE 1 END
       FOR UPDATE`,
      [req.user.companyId]
    )

    // Mescla a lista dedicada com a lista antiga sem descartar registros.
    // Em caso de duplicidade para funcionário/data, a lista dedicada prevalece.
    const recordsByEmployeeDay = new Map()
    for (const row of [...currentResult.rows].reverse()) {
      const payload = Array.isArray(row.payload) ? row.payload : []
      for (const item of payload) {
        const key = `${String(item?.employeeId)}:${String(item?.date)}`
        recordsByEmployeeDay.set(key, item)
      }
    }
    const records = [...recordsByEmployeeDay.values()]

    let record = records.find((item) =>
      aliases.has(String(item?.employeeId)) && String(item?.date) === date
    )

    const nextType = (currentRecord) => {
      const punches = Array.isArray(currentRecord?.punches) ? currentRecord.punches : []
      if (!punches.length) return 'entry'
      switch (punches[punches.length - 1]?.type) {
        case 'entry': return 'break_start'
        case 'break_start': return 'break_end'
        case 'break_end': return 'exit'
        default: return null
      }
    }

    const punchType = nextType(record)
    if (!punchType) {
      await client.query('ROLLBACK')
      return res.status(409).json({ message: 'Todas as batidas previstas para hoje já foram registradas.' })
    }

    if (!record) {
      record = {
        id: `${employeeRow.id}-${date}`,
        employeeId: employeeRow.id,
        date,
        punches: [],
        createdAt: now,
        updatedAt: now
      }
      records.push(record)
    } else {
      // Normaliza o vínculo antigo para o ID oficial do PostgreSQL.
      record.employeeId = employeeRow.id
    }

    const punch = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
      type: punchType,
      time,
      registeredAt: now,
      source,
      registrationMethod: source,
      location
    }
    record.punches = [...(Array.isArray(record.punches) ? record.punches : []), punch]
    record.updatedAt = now

    await client.query(
      `INSERT INTO app_records
         (company_id, module_key, record_key, payload, created_by, updated_by)
       VALUES ($1, 'timekeeping_clock', 'timeClockRecords', $2::jsonb, $3, $3)
       ON CONFLICT (company_id, module_key, record_key)
       DO UPDATE SET payload = EXCLUDED.payload,
                     updated_by = EXCLUDED.updated_by,
                     updated_at = NOW()`,
      [req.user.companyId, JSON.stringify(records), req.user.userId || null]
    )

    await client.query('COMMIT')
    return res.status(201).json({
      record,
      punch,
      nextPunchType: nextType(record)
    })
  } catch (error) {
    await client.query('ROLLBACK')
    return next(error)
  } finally {
    client.release()
  }
})


// Espelho do funcionário autenticado. A API devolve somente as marcações
// e as jornadas necessárias ao período solicitado, sem aceitar employeeId.
router.get('/timekeeping/period', requirePermission('ponto_espelho_view'), async (req, res, next) => {
  const startDate = typeof req.query.startDate === 'string' ? req.query.startDate : ''
  const endDate = typeof req.query.endDate === 'string' ? req.query.endDate : ''
  const isoDate = /^\d{4}-\d{2}-\d{2}$/

  if (!isoDate.test(startDate) || !isoDate.test(endDate)) {
    return res.status(400).json({ message: 'Informe datas válidas no formato AAAA-MM-DD.' })
  }

  const start = new Date(`${startDate}T00:00:00.000Z`)
  const end = new Date(`${endDate}T00:00:00.000Z`)
  const days = Math.round((end - start) / 86400000)

  if (!Number.isFinite(days) || days < 0 || days > 366) {
    return res.status(400).json({ message: 'O período deve ter entre 1 e 367 dias.' })
  }

  if (!req.user?.employeeId) {
    return res.status(403).json({ message: 'Esta conta não está vinculada a um funcionário.' })
  }

  try {
    const employeeResult = await pool.query(
      `SELECT e.id, e.name, e.status, e.registration_data,
              p.name AS position_name
       FROM employees e
       LEFT JOIN positions p
         ON p.id = e.position_id AND p.company_id = e.company_id
       WHERE e.id = $1 AND e.company_id = $2`,
      [req.user.employeeId, req.user.companyId]
    )

    if (!employeeResult.rowCount) {
      return res.status(404).json({ message: 'Funcionário vinculado não encontrado.' })
    }

    const employeeRow = employeeResult.rows[0]
    const registrationData = employeeRow.registration_data || {}
    const employee = {
      id: employeeRow.id,
      name: employeeRow.name || registrationData.name || '',
      status: employeeRow.status || 'active',
      position: employeeRow.position_name || registrationData.position || registrationData.jobTitle || '',
      jobTitle: registrationData.jobTitle || employeeRow.position_name || ''
    }

    const aliases = new Set([
      String(employeeRow.id),
      registrationData.legacyId == null ? '' : String(registrationData.legacyId),
      registrationData.legacy_id == null ? '' : String(registrationData.legacy_id),
      registrationData.id == null ? '' : String(registrationData.id)
    ].filter(Boolean))

    const recordsResult = await pool.query(
      `SELECT module_key, record_key, payload
       FROM app_records
       WHERE company_id = $1
         AND module_key IN ('timekeeping_clock', 'timekeeping')
         AND record_key = 'timeClockRecords'
       ORDER BY CASE WHEN module_key = 'timekeeping_clock' THEN 0 ELSE 1 END`,
      [req.user.companyId]
    )

    const recordsByDate = new Map()
    for (const row of recordsResult.rows) {
      const items = Array.isArray(row.payload) ? row.payload : []
      for (const item of items) {
        const itemDate = String(item?.date || '')
        if (
          aliases.has(String(item?.employeeId)) &&
          itemDate >= startDate &&
          itemDate <= endDate &&
          !recordsByDate.has(itemDate)
        ) {
          // Normaliza o vínculo para o UUID oficial, sem alterar o registro no banco.
          recordsByDate.set(itemDate, { ...item, employeeId: employeeRow.id })
        }
      }
    }

    const scheduleResult = await pool.query(
      `SELECT record_key, payload
       FROM app_records
       WHERE company_id = $1
         AND module_key = 'timekeeping_schedules'
         AND record_key IN ('workSchedules', 'employeeWorkSchedules')`,
      [req.user.companyId]
    )

    const schedulePayloads = Object.fromEntries(
      scheduleResult.rows.map((row) => [row.record_key, Array.isArray(row.payload) ? row.payload : []])
    )

    const allAssignments = schedulePayloads.employeeWorkSchedules || []
    const assignments = allAssignments
      .filter((item) => aliases.has(String(item?.employeeId)))
      .map((item) => ({ ...item, employeeId: employeeRow.id }))

    const scheduleIds = new Set(assignments.map((item) => String(item?.scheduleId)))
    const workSchedules = (schedulePayloads.workSchedules || []).filter((item) =>
      scheduleIds.has(String(item?.id))
    )

    return res.json({
      employee,
      records: [...recordsByDate.values()],
      scheduleData: {
        workSchedules,
        employeeWorkSchedules: assignments
      },
      startDate,
      endDate
    })
  } catch (error) {
    return next(error)
  }
})


// Carrega dados de ponto limitados à empresa autenticada e ao período solicitado.
// A lista de atestados só é incluída nas respostas que precisam apurar faltas.
async function loadTimekeepingDataset(companyId, startDate, endDate, includeMedicalCertificates = false) {
  const [employeeResult, branchResult, recordsResult, schedulesResult, medicalResult] = await Promise.all([
    pool.query(
      `SELECT e.*, b.name AS branch_name, d.name AS department_name,
              r.name AS role_name, p.name AS position_name
       FROM employees e
       LEFT JOIN branches b ON b.id = e.branch_id AND b.company_id = e.company_id
       LEFT JOIN departments d ON d.id = e.department_id AND d.company_id = e.company_id
       LEFT JOIN roles r ON r.id = e.role_id AND r.company_id = e.company_id
       LEFT JOIN positions p ON p.id = e.position_id AND p.company_id = e.company_id
       WHERE e.company_id = $1
       ORDER BY e.name`,
      [companyId]
    ),
    pool.query(
      `SELECT id, name, active FROM branches WHERE company_id = $1 ORDER BY name`,
      [companyId]
    ),
    pool.query(
      `SELECT module_key, record_key, payload FROM app_records
       WHERE company_id = $1
         AND module_key IN ('timekeeping_clock', 'timekeeping')
         AND record_key = 'timeClockRecords'
       ORDER BY CASE WHEN module_key = 'timekeeping_clock' THEN 0 ELSE 1 END`,
      [companyId]
    ),
    pool.query(
      `SELECT record_key, payload FROM app_records
       WHERE company_id = $1 AND module_key = 'timekeeping_schedules'
         AND record_key IN ('workSchedules', 'employeeWorkSchedules')`,
      [companyId]
    ),
    includeMedicalCertificates
      ? pool.query(
          `SELECT payload FROM app_records
           WHERE company_id = $1 AND module_key = 'timekeeping_medical'
             AND record_key = 'medicalCertificates'`,
          [companyId]
        )
      : Promise.resolve({ rows: [] })
  ])

  const employees = employeeResult.rows.map((row) => {
    const data = row.registration_data && typeof row.registration_data === 'object'
      ? row.registration_data
      : {}
    return {
      ...data,
      id: row.id,
      name: row.name || data.name || '',
      status: row.status || 'active',
      active: row.status ? row.status === 'active' : data.active !== false,
      cpf: row.cpf || data.cpf || '',
      email: row.email || data.email || '',
      registration: row.registration || data.registration || data.employeeNumber || '',
      branchId: row.branch_id || data.branchId || '',
      branchName: row.branch_name || data.branchName || '',
      departmentId: row.department_id || data.departmentId || '',
      departmentName: row.department_name || data.departmentName || '',
      roleId: row.role_id || data.roleId || '',
      roleName: row.role_name || data.roleName || '',
      positionId: row.position_id || data.positionId || '',
      position: row.position_name || data.position || data.jobTitle || '',
      jobTitle: data.jobTitle || row.position_name || row.role_name || '',
      legacyId: data.legacyId ?? data.legacy_id ?? data.id ?? null,
      admissionDate: row.admission_date || data.admissionDate || '',
      terminationDate: row.termination_date || data.terminationDate || '',
      weeklyHours: data.weeklyHours ?? data.weekly_hours ?? row.weekly_hours ?? null
    }
  })

  const aliases = new Map()
  for (const employee of employees) {
    for (const alias of [employee.id, employee.legacyId, employee.legacy_id, employee.idLegacy]) {
      if (alias !== undefined && alias !== null && alias !== '') aliases.set(String(alias), String(employee.id))
    }
  }

  const recordsByEmployeeDate = new Map()
  for (const row of recordsResult.rows) {
    for (const item of (Array.isArray(row.payload) ? row.payload : [])) {
      const date = String(item?.date || '')
      if (date < startDate || date > endDate) continue
      const employeeId = aliases.get(String(item?.employeeId))
      if (!employeeId) continue
      const key = `${employeeId}::${date}`
      if (!recordsByEmployeeDate.has(key)) recordsByEmployeeDate.set(key, { ...item, employeeId })
    }
  }

  const schedulePayloads = Object.fromEntries(
    schedulesResult.rows.map((row) => [row.record_key, Array.isArray(row.payload) ? row.payload : []])
  )
  const assignments = (schedulePayloads.employeeWorkSchedules || [])
    .map((item) => {
      const employeeId = aliases.get(String(item?.employeeId))
      return employeeId ? { ...item, employeeId } : null
    })
    .filter(Boolean)

  const medicalCertificates = includeMedicalCertificates
    ? medicalResult.rows.flatMap((row) => Array.isArray(row.payload) ? row.payload : [])
      .map((certificate) => {
        const employeeId = aliases.get(String(certificate?.employeeId))
        return employeeId ? { ...certificate, employeeId } : null
      })
      .filter((certificate) => certificate && certificate.startDate && certificate.endDate &&
        certificate.startDate <= endDate && certificate.endDate >= startDate)
    : undefined

  return {
    employees,
    branches: branchResult.rows,
    records: [...recordsByEmployeeDate.values()],
    scheduleData: {
      workSchedules: schedulePayloads.workSchedules || [],
      employeeWorkSchedules: assignments
    },
    ...(includeMedicalCertificates ? { medicalCertificates } : {}),
    startDate,
    endDate
  }
}

function validateTimekeepingPeriod(req, res) {
  const startDate = typeof req.query.startDate === 'string' ? req.query.startDate : ''
  const endDate = typeof req.query.endDate === 'string' ? req.query.endDate : ''
  const isoDate = /^\d{4}-\d{2}-\d{2}$/
  if (!isoDate.test(startDate) || !isoDate.test(endDate)) {
    res.status(400).json({ message: 'Informe datas válidas no formato AAAA-MM-DD.' })
    return null
  }
  const start = new Date(`${startDate}T00:00:00.000Z`)
  const end = new Date(`${endDate}T00:00:00.000Z`)
  const dayCount = Math.round((end - start) / 86400000) + 1
  if (!Number.isFinite(dayCount) || dayCount < 1 || dayCount > 367) {
    res.status(400).json({ message: 'O período deve abranger de 1 a 367 dias.' })
    return null
  }
  return { startDate, endDate }
}

// Relatórios gerais de ponto.
router.get('/timekeeping/report-data', requirePermission('ponto_controle_view'), async (req, res, next) => {
  const period = validateTimekeepingPeriod(req, res)
  if (!period) return
  try {
    return res.json(await loadTimekeepingDataset(req.user.companyId, period.startDate, period.endDate, true))
  } catch (error) {
    return next(error)
  }
})

// Horas extras: permissão específica e sem expor dados de atestados.
router.get('/timekeeping/overtime-data', requirePermission('ponto_horas_extras_view'), async (req, res, next) => {
  const period = validateTimekeepingPeriod(req, res)
  if (!period) return
  try {
    return res.json(await loadTimekeepingDataset(req.user.companyId, period.startDate, period.endDate, false))
  } catch (error) {
    return next(error)
  }
})

// Faltas e atrasos: inclui apenas os atestados necessários à apuração.
router.get('/timekeeping/absence-data', requirePermission('ponto_faltas_view'), async (req, res, next) => {
  const period = validateTimekeepingPeriod(req, res)
  if (!period) return
  try {
    return res.json(await loadTimekeepingDataset(req.user.companyId, period.startDate, period.endDate, true))
  } catch (error) {
    return next(error)
  }
})


// Dataset exclusivo do Fechamento Mensal. A permissão do endpoint é própria
// deste domínio; não reutilizamos a rota de relatórios que exige Controle geral.
router.get('/timekeeping/closing-data', requirePermission('ponto_fechamento_view'), async (req, res, next) => {
  const startDate = typeof req.query.startDate === 'string' ? req.query.startDate : ''
  const endDate = typeof req.query.endDate === 'string' ? req.query.endDate : ''
  const isoDate = /^\d{4}-\d{2}-\d{2}$/
  if (!isoDate.test(startDate) || !isoDate.test(endDate)) {
    return res.status(400).json({ message: 'Informe datas válidas no formato AAAA-MM-DD.' })
  }
  const start = new Date(`${startDate}T00:00:00.000Z`)
  const end = new Date(`${endDate}T00:00:00.000Z`)
  const dayCount = Math.round((end - start) / 86400000) + 1
  if (!Number.isFinite(dayCount) || dayCount < 1 || dayCount > 367) {
    return res.status(400).json({ message: 'A competência deve abranger de 1 a 367 dias.' })
  }

  try {
    const [employeeResult, branchResult, recordsResult, schedulesResult] = await Promise.all([
      pool.query(
        `SELECT e.*, b.name AS branch_name, d.name AS department_name,
                r.name AS role_name, p.name AS position_name
         FROM employees e
         LEFT JOIN branches b ON b.id = e.branch_id AND b.company_id = e.company_id
         LEFT JOIN departments d ON d.id = e.department_id AND d.company_id = e.company_id
         LEFT JOIN roles r ON r.id = e.role_id AND r.company_id = e.company_id
         LEFT JOIN positions p ON p.id = e.position_id AND p.company_id = e.company_id
         WHERE e.company_id = $1
         ORDER BY e.name`,
        [req.user.companyId]
      ),
      pool.query(
        `SELECT id, name, active FROM branches
         WHERE company_id = $1 ORDER BY name`,
        [req.user.companyId]
      ),
      pool.query(
        `SELECT module_key, payload
         FROM app_records
         WHERE company_id = $1
           AND module_key IN ('timekeeping_clock', 'timekeeping')
           AND record_key = 'timeClockRecords'
         ORDER BY CASE WHEN module_key = 'timekeeping_clock' THEN 0 ELSE 1 END`,
        [req.user.companyId]
      ),
      pool.query(
        `SELECT record_key, payload
         FROM app_records
         WHERE company_id = $1 AND module_key = 'timekeeping_schedules'
           AND record_key IN ('workSchedules', 'employeeWorkSchedules')`,
        [req.user.companyId]
      )
    ])

    const employees = employeeResult.rows.map((row) => {
      const data = row.registration_data && typeof row.registration_data === 'object'
        ? row.registration_data
        : {}
      return {
        ...data,
        id: row.id,
        name: row.name || data.name || '',
        status: row.status || 'active',
        active: row.status ? row.status === 'active' : data.active !== false,
        branchId: row.branch_id || data.branchId || '',
        branchName: row.branch_name || data.branchName || '',
        departmentId: row.department_id || data.departmentId || '',
        departmentName: row.department_name || data.departmentName || '',
        roleId: row.role_id || data.roleId || '',
        roleName: row.role_name || data.roleName || '',
        positionId: row.position_id || data.positionId || '',
        position: row.position_name || data.position || data.jobTitle || '',
        jobTitle: data.jobTitle || row.position_name || row.role_name || '',
        weeklyHours: data.weeklyHours ?? data.weekly_hours ?? row.weekly_hours ?? null,
        legacyId: data.legacyId ?? data.legacy_id ?? data.id ?? null
      }
    })

    const aliases = new Map()
    for (const employee of employees) {
      for (const alias of [employee.id, employee.legacyId, employee.legacy_id, employee.idLegacy]) {
        if (alias !== undefined && alias !== null && alias !== '') aliases.set(String(alias), String(employee.id))
      }
    }

    const recordsByDate = new Map()
    for (const row of recordsResult.rows) {
      for (const item of (Array.isArray(row.payload) ? row.payload : [])) {
        const date = String(item?.date || '')
        if (date < startDate || date > endDate) continue
        const employeeId = aliases.get(String(item?.employeeId))
        if (!employeeId) continue
        const key = `${employeeId}::${date}`
        if (!recordsByDate.has(key)) recordsByDate.set(key, { ...item, employeeId })
      }
    }

    const schedulePayloads = Object.fromEntries(
      schedulesResult.rows.map((row) => [row.record_key, Array.isArray(row.payload) ? row.payload : []])
    )
    const employeeWorkSchedules = (schedulePayloads.employeeWorkSchedules || [])
      .map((assignment) => {
        const employeeId = aliases.get(String(assignment?.employeeId))
        return employeeId ? { ...assignment, employeeId } : null
      })
      .filter(Boolean)

    const scheduleIds = new Set(employeeWorkSchedules.map((item) => String(item.scheduleId)))
    const workSchedules = (schedulePayloads.workSchedules || []).filter((item) => scheduleIds.has(String(item?.id)))

    return res.json({
      employees,
      branches: branchResult.rows,
      records: [...recordsByDate.values()],
      scheduleData: { workSchedules, employeeWorkSchedules },
      startDate,
      endDate
    })
  } catch (error) {
    return next(error)
  }
})


/**
 * Portal do funcionário: devolve somente workflows de avaliação vinculados
 * ao funcionário autenticado. A lista completa nunca é enviada ao navegador.
 */
router.get('/evaluation-workflows', async (req, res, next) => {
  const permissions = Array.isArray(req.user?.permissions) ? req.user.permissions : []
  const canManageEvaluations = req.user?.isAdmin === true ||
    ['evaluations_create', 'evaluations_edit', 'evaluations_delete'].some((permission) => permissions.includes(permission))
  if (!req.user?.employeeId && !canManageEvaluations) {
    return res.status(400).json({ message: 'Esta conta não está vinculada a um funcionário.' })
  }

  try {
    let aliases = new Set()
    if (req.user?.employeeId) {
      const employeeResult = await pool.query(
        `SELECT id, registration_data
         FROM employees
         WHERE id = $1 AND company_id = $2`,
        [req.user.employeeId, req.user.companyId]
      )
      if (!employeeResult.rowCount) {
        return res.status(404).json({ message: 'Funcionário não encontrado.' })
      }

      const employee = employeeResult.rows[0]
      const registration = employee.registration_data || {}
      aliases = new Set([
        employee.id,
        registration.legacyId,
        registration.legacy_id,
        registration.id
      ].filter((value) => value !== null && value !== undefined).map(String))
    }

    const result = await pool.query(
      `SELECT payload
       FROM app_records
       WHERE company_id = $1
         AND module_key = 'evaluations'
         AND record_key = 'evaluationWorkflows'
       LIMIT 1`,
      [req.user.companyId]
    )

    const workflows = Array.isArray(result.rows[0]?.payload) ? result.rows[0].payload : []

    return res.json(workflows.filter((workflow) => {
      const candidates = [
        workflow?.employeeId,
        workflow?.employee?.id,
        workflow?.employee?.employeeId
      ].filter((value) => value !== null && value !== undefined).map(String)
      const isEvaluatedEmployee = candidates.some((value) => aliases.has(value))
      const isPdiResponsible =
        String(workflow?.pdi?.responsibleUserId || '') === String(req.user.userId || '') ||
        aliases.has(String(workflow?.pdi?.responsibleEmployeeId || ''))
      return isEvaluatedEmployee || isPdiResponsible || canManageEvaluations
    }))
  } catch (error) {
    return next(error)
  }
})

/**
 * Atualiza somente o PDI de um workflow ao qual o usuário está autorizado.
 * O cliente envia respostas, nunca IDs de funcionário ou dados completos do workflow.
 */
router.post('/evaluation-workflows/:workflowId/pdi', async (req, res, next) => {
  const permissions = Array.isArray(req.user?.permissions) ? req.user.permissions : []
  const canManageEvaluations = req.user?.isAdmin === true ||
    ['evaluations_create', 'evaluations_edit', 'evaluations_delete'].some((permission) => permissions.includes(permission))
  if (!req.user?.employeeId && !canManageEvaluations) {
    return res.status(400).json({ message: 'Esta conta não está vinculada a um funcionário.' })
  }

  const workflowId = String(req.params.workflowId || '')
  const action = req.body?.action
  const answers = req.body?.answers && typeof req.body.answers === 'object' &&
    !Array.isArray(req.body.answers) ? req.body.answers : {}

  if (!workflowId || workflowId.length > 180 || !['start', 'save', 'complete'].includes(action)) {
    return res.status(400).json({ message: 'Ação ou avaliação inválida.' })
  }

  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    await client.query(
      'SELECT pg_advisory_xact_lock(hashtext($1), hashtext($2))',
      [String(req.user.companyId), 'evaluations:evaluationWorkflows']
    )

    let employee = { name: req.user.name || '', username: req.user.username || '', registration_data: {} }
    let aliases = new Set()
    if (req.user?.employeeId) {
      const employeeResult = await client.query(
        `SELECT e.id, e.name, u.username, e.registration_data
         FROM employees e
         LEFT JOIN users u ON u.employee_id = e.id AND u.company_id = e.company_id AND u.id = $3
         WHERE e.id = $1 AND e.company_id = $2`,
        [req.user.employeeId, req.user.companyId, req.user.userId]
      )
      if (!employeeResult.rowCount) {
        await client.query('ROLLBACK')
        return res.status(404).json({ message: 'Funcionário não encontrado.' })
      }

      employee = employeeResult.rows[0]
      const registration = employee.registration_data || {}
      aliases = new Set([
        employee.id,
        registration.legacyId,
        registration.legacy_id,
        registration.id
      ].filter((value) => value !== null && value !== undefined).map(String))
    }

    const recordResult = await client.query(
      `SELECT payload
       FROM app_records
       WHERE company_id = $1
         AND module_key = 'evaluations'
         AND record_key = 'evaluationWorkflows'
       FOR UPDATE`,
      [req.user.companyId]
    )
    if (!recordResult.rowCount || !Array.isArray(recordResult.rows[0].payload)) {
      await client.query('ROLLBACK')
      return res.status(404).json({ message: 'Avaliações não encontradas.' })
    }

    const workflows = recordResult.rows[0].payload
    const index = workflows.findIndex((workflow) => String(workflow?.id) === workflowId)

    if (index < 0) {
      await client.query('ROLLBACK')
      return res.status(404).json({ message: 'Avaliação não encontrada para este funcionário.' })
    }

    const workflow = workflows[index]
    const isPdiResponsible =
      String(workflow?.pdi?.responsibleUserId || '') === String(req.user.userId || '') ||
      aliases.has(String(workflow?.pdi?.responsibleEmployeeId || ''))
    if (!canManageEvaluations && !isPdiResponsible) {
      await client.query('ROLLBACK')
      return res.status(403).json({ message: 'Somente o responsável pelo PDI ou a Gestão de RH pode alterá-lo.' })
    }

    const pdi = workflow.pdi && typeof workflow.pdi === 'object' ? workflow.pdi : null
    if (!pdi || !Array.isArray(pdi.questions)) {
      await client.query('ROLLBACK')
      return res.status(400).json({ message: 'Esta avaliação não possui um PDI válido.' })
    }
    if (pdi.status === 'completed') {
      await client.query('ROLLBACK')
      return res.status(409).json({ message: 'Este PDI já foi concluído.' })
    }

    const now = new Date().toISOString()
    const userName = employee.name || req.user.name || req.user.username || 'Funcionário'
    let updatedPdi = { ...pdi }

    if (action === 'start') {
      updatedPdi = {
        ...updatedPdi,
        status: 'in_progress',
        startedAt: updatedPdi.startedAt || now,
        startedByUserId: req.user.userId || '',
        startedByUserName: userName
      }
    } else {
      const questions = updatedPdi.questions.map((question) => {
        if (!Object.prototype.hasOwnProperty.call(answers, String(question.id))) return question
        const rawAnswer = answers[String(question.id)]
        const answer = typeof rawAnswer === 'string' ? rawAnswer.trim().slice(0, 10000) : String(rawAnswer ?? '').slice(0, 10000)
        return { ...question, answer, answeredAt: now }
      })

      updatedPdi = {
        ...updatedPdi,
        questions,
        status: 'in_progress',
        startedAt: updatedPdi.startedAt || now
      }

      if (action === 'complete') {
        const unanswered = questions.filter((question) =>
          question.required !== false && !String(question.answer ?? '').trim()
        )
        if (unanswered.length) {
          await client.query('ROLLBACK')
          return res.status(400).json({
            message: 'Responda todas as perguntas obrigatórias antes de concluir o PDI.',
            errors: unanswered.map((question, index) => `Pergunta obrigatória pendente: ${question.text || index + 1}`)
          })
        }

        updatedPdi = {
          ...updatedPdi,
          status: 'completed',
          completedAt: now,
          completedByUserId: req.user.userId || '',
          completedByUserName: userName
        }
      }
    }

    const updatedWorkflow = {
      ...workflow,
      pdi: updatedPdi,
      updatedAt: now
    }
    workflows[index] = updatedWorkflow

    await client.query(
      `UPDATE app_records
       SET payload = $2::jsonb, updated_by = $3, updated_at = NOW()
       WHERE company_id = $1 AND module_key = 'evaluations' AND record_key = 'evaluationWorkflows'`,
      [req.user.companyId, JSON.stringify(workflows), req.user.userId || null]
    )

    await client.query('COMMIT')
    return res.json({ workflow: updatedWorkflow })
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {})
    return next(error)
  } finally {
    client.release()
  }
})

router.get('/documents', async (req, res, next) => {
  try {
    if (!req.user.employeeId) return res.json([])

    const result = await pool.query(
      `SELECT id, category, document_type, file_name,
              mime_type, size_bytes, expires_at, status, created_at
       FROM employee_documents
       WHERE company_id = $1 AND employee_id = $2
       ORDER BY created_at DESC`,
      [req.user.companyId, req.user.employeeId]
    )

    return res.json(result.rows)
  } catch (error) {
    return next(error)
  }
})

router.get('/payrolls', async (req, res, next) => {
  try {
    if (!req.user.employeeId) return res.json([])

    const result = await pool.query(
      `SELECT
        p.id, p.competence, p.status,
        pi.base_salary, pi.earnings, pi.deductions,
        pi.inss, pi.irrf, pi.fgts, pi.net_salary,
        pi.overtime_minutes, pi.overtime_amount
       FROM payrolls p
       JOIN payroll_items pi ON pi.payroll_id = p.id
       WHERE p.company_id = $1
         AND pi.employee_id = $2
         AND p.status = 'closed'
       ORDER BY p.competence DESC`,
      [req.user.companyId, req.user.employeeId]
    )

    return res.json(result.rows)
  } catch (error) {
    return next(error)
  }
})


// Portal do funcionário: entrega somente os treinamentos atribuídos ao usuário autenticado.
// Os arrays legados continuam no app_records durante a migração gradual.
router.get('/training-data', async (req, res, next) => {
  if (!req.user?.employeeId) {
    return res.json({
      trainings: [],
      participant: null,
      assessments: [],
      certificates: []
    })
  }

  try {
    const employeeResult = await pool.query(
      `SELECT id, registration_data
       FROM employees
       WHERE id = $1 AND company_id = $2`,
      [req.user.employeeId, req.user.companyId]
    )

    if (!employeeResult.rowCount) {
      return res.json({
        trainings: [],
        participant: null,
        assessments: [],
        certificates: []
      })
    }

    const employee = employeeResult.rows[0]
    const registrationData = employee.registration_data || {}
    const employeeAliases = new Set([
      employee.id,
      registrationData.legacyId,
      registrationData.legacy_id,
      registrationData.id
    ].filter((value) => value !== undefined && value !== null).map(String))

    const recordsResult = await pool.query(
      `SELECT record_key AS "recordKey", payload
       FROM app_records
       WHERE company_id = $1
         AND module_key = 'trainings'
         AND record_key = ANY($2::text[])`,
      [req.user.companyId, [
        'trainings',
        'trainingParticipants',
        'trainingAssessments',
        'trainingCertificates'
      ]]
    )
    const records = new Map(recordsResult.rows.map((row) => [
      row.recordKey,
      Array.isArray(row.payload) ? row.payload : []
    ]))

    const allParticipants = records.get('trainingParticipants') || []
    const myParticipants = allParticipants.filter((participant) =>
      employeeAliases.has(String(participant.employeeId))
    )
    const trainingIds = new Set(myParticipants.map((participant) => String(participant.trainingId)))
    const trainings = (records.get('trainings') || []).filter((training) =>
      trainingIds.has(String(training.id))
    )
    const assessmentIds = new Set(trainings.map((training) => String(training.id)))
    const assessments = (records.get('trainingAssessments') || []).filter((assessment) =>
      assessmentIds.has(String(assessment.trainingId))
    )
    const participantIds = new Set(myParticipants.map((participant) => String(participant.id)))
    const certificates = (records.get('trainingCertificates') || []).filter((certificate) =>
      participantIds.has(String(certificate.participantId)) ||
      employeeAliases.has(String(certificate.employeeId)) ||
      trainingIds.has(String(certificate.trainingId)) && employeeAliases.has(String(certificate.employeeId))
    )

    return res.json({
      trainings,
      participants: myParticipants,
      assessments,
      certificates
    })
  } catch (error) {
    return next(error)
  }
})



/*
 * Persistência do portal Meus Treinamentos.
 *
 * Os registros legados continuam no app_records, mas as alterações passam
 * pelo servidor e são limitadas ao funcionário autenticado. O navegador não
 * pode enviar nota, aprovação ou percentual como valores confiáveis.
 */
async function getTrainingEmployeeAliases(client, req) {
  if (!req.user?.employeeId) return new Set()
  const result = await client.query(
    `SELECT id, registration_data
     FROM employees
     WHERE id = $1 AND company_id = $2`,
    [req.user.employeeId, req.user.companyId]
  )
  if (!result.rowCount) return new Set()
  const employee = result.rows[0]
  const data = employee.registration_data || {}
  return new Set([
    employee.id,
    data.legacyId,
    data.legacy_id,
    data.id
  ].filter((value) => value !== undefined && value !== null).map(String))
}

async function readTrainingArray(client, companyId, recordKey, lock = false) {
  const result = await client.query(
    `SELECT payload
     FROM app_records
     WHERE company_id = $1 AND module_key = 'trainings' AND record_key = $2
     ${lock ? 'FOR UPDATE' : ''}`,
    [companyId, recordKey]
  )
  return result.rowCount && Array.isArray(result.rows[0].payload)
    ? result.rows[0].payload
    : []
}

async function saveTrainingArray(client, req, recordKey, payload) {
  await client.query(
    `INSERT INTO app_records
       (company_id, module_key, record_key, payload, created_by, updated_by)
     VALUES ($1, 'trainings', $2, $3::jsonb, $4, $4)
     ON CONFLICT (company_id, module_key, record_key)
     DO UPDATE SET payload = EXCLUDED.payload,
                   updated_by = EXCLUDED.updated_by,
                   updated_at = NOW()`,
    [req.user.companyId, recordKey, JSON.stringify(payload), req.user.userId || null]
  )
}

function participantBelongsToEmployee(participant, aliases) {
  return aliases.has(String(participant?.employeeId))
}

function getParticipantIndex(participants, participantId, aliases) {
  return participants.findIndex((participant) =>
    String(participant.id) === String(participantId) &&
    participantBelongsToEmployee(participant, aliases)
  )
}

router.patch('/training-progress', async (req, res, next) => {
  const participantId = req.body?.participantId
  const completedContents = req.body?.completedContents
  if (participantId === undefined || !Array.isArray(completedContents)) {
    return res.status(400).json({ message: 'Informe a participação e a lista de conteúdos concluídos.' })
  }
  if (completedContents.length > 1000) {
    return res.status(400).json({ message: 'A lista de conteúdos excede o limite permitido.' })
  }

  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    const aliases = await getTrainingEmployeeAliases(client, req)
    if (!aliases.size) {
      await client.query('ROLLBACK')
      return res.status(403).json({ message: 'Não existe funcionário vinculado à sessão.' })
    }

    const participants = await readTrainingArray(client, req.user.companyId, 'trainingParticipants', true)
    const participantIndex = getParticipantIndex(participants, participantId, aliases)
    if (participantIndex < 0) {
      await client.query('ROLLBACK')
      return res.status(404).json({ message: 'Participação não encontrada para o funcionário autenticado.' })
    }

    const participant = participants[participantIndex]
    const trainings = await readTrainingArray(client, req.user.companyId, 'trainings')
    const training = trainings.find((item) => String(item.id) === String(participant.trainingId))
    if (!training) {
      await client.query('ROLLBACK')
      return res.status(404).json({ message: 'Treinamento relacionado não encontrado.' })
    }

    const validContentIds = new Set((Array.isArray(training.contents) ? training.contents : [])
      .map((content) => String(content.id)))
    const requestedIds = [...new Set(completedContents.map(String))]
    if (requestedIds.some((id) => !validContentIds.has(id))) {
      await client.query('ROLLBACK')
      return res.status(400).json({ message: 'A lista contém conteúdos que não pertencem a este treinamento.' })
    }

    const progress = validContentIds.size
      ? Math.round((requestedIds.length / validContentIds.size) * 100)
      : 0
    const assessmentStatus = participant.assessmentStatus || null
    const status = assessmentStatus === 'failed'
      ? 'failed'
      : progress > 0 ? 'in_progress' : 'pending'
    const updatedParticipant = {
      ...participant,
      completedContents: requestedIds,
      progress,
      status,
      completedAt: status === 'completed' ? participant.completedAt || new Date().toISOString() : null
    }
    participants[participantIndex] = updatedParticipant
    await saveTrainingArray(client, req, 'trainingParticipants', participants)
    await client.query('COMMIT')
    return res.json({ participant: updatedParticipant })
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {})
    return next(error)
  } finally {
    client.release()
  }
})

router.post('/training-attempt', async (req, res, next) => {
  const participantId = req.body?.participantId
  const submittedAnswers = req.body?.answers
  if (participantId === undefined || !submittedAnswers || typeof submittedAnswers !== 'object' || Array.isArray(submittedAnswers)) {
    return res.status(400).json({ message: 'Informe a participação e as respostas da avaliação.' })
  }

  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    const aliases = await getTrainingEmployeeAliases(client, req)
    if (!aliases.size) {
      await client.query('ROLLBACK')
      return res.status(403).json({ message: 'Não existe funcionário vinculado à sessão.' })
    }

    const participants = await readTrainingArray(client, req.user.companyId, 'trainingParticipants', true)
    const participantIndex = getParticipantIndex(participants, participantId, aliases)
    if (participantIndex < 0) {
      await client.query('ROLLBACK')
      return res.status(404).json({ message: 'Participação não encontrada para o funcionário autenticado.' })
    }
    const participant = participants[participantIndex]
    const assessments = await readTrainingArray(client, req.user.companyId, 'trainingAssessments')
    const assessment = assessments.find((item) => String(item.trainingId) === String(participant.trainingId))
    if (!assessment) {
      await client.query('ROLLBACK')
      return res.status(404).json({ message: 'Avaliação deste treinamento não encontrada.' })
    }

    const questions = Array.isArray(assessment.questions) ? assessment.questions : []
    if (!questions.length) {
      await client.query('ROLLBACK')
      return res.status(400).json({ message: 'Esta avaliação ainda não possui perguntas.' })
    }
    const invalidQuestions = questions.filter((question) =>
      !Array.isArray(question.alternatives) ||
      question.alternatives.length < 4 ||
      question.alternatives.some((alternative) => !String(alternative || '').trim())
    )
    if (invalidQuestions.length) {
      await client.query('ROLLBACK')
      return res.status(400).json({ message: 'A avaliação contém perguntas sem quatro alternativas válidas.' })
    }

    const attempts = Array.isArray(participant.attempts) ? participant.attempts : []
    let attemptLimit = 1
    if (assessment.allowRetake !== false) {
      if (assessment.unlimitedAttempts === true) attemptLimit = Infinity
      else {
        const configuredLimit = Number(assessment.maxAttempts)
        attemptLimit = configuredLimit >= 2 ? Math.floor(configuredLimit) : 1
      }
    }
    if (attempts.length >= attemptLimit) {
      await client.query('ROLLBACK')
      return res.status(409).json({ message: 'O limite de tentativas desta avaliação foi atingido.' })
    }

    const unanswered = questions.filter((question) =>
      submittedAnswers[question.id] === undefined ||
      !Number.isInteger(Number(submittedAnswers[question.id])) ||
      Number(submittedAnswers[question.id]) < 0 ||
      Number(submittedAnswers[question.id]) >= question.alternatives.length
    )
    if (unanswered.length) {
      await client.query('ROLLBACK')
      return res.status(400).json({ message: 'Responda todas as perguntas com uma alternativa válida.' })
    }

    let earnedPoints = 0
    let totalPoints = 0
    for (const question of questions) {
      const points = Math.max(0, Number(question.points) || 1)
      totalPoints += points
      if (Number(submittedAnswers[question.id]) === Number(question.correctAnswer)) earnedPoints += points
    }
    const score = totalPoints > 0 ? Math.round((earnedPoints / totalPoints) * 100) : 0
    const minimumScore = Math.max(0, Number(assessment.minimumScore) || 0)
    const priorScores = attempts.map((attempt) => Number(attempt.score)).filter(Number.isFinite)
    const existingBest = Number.isFinite(Number(participant.bestScore))
      ? Number(participant.bestScore)
      : Number.isFinite(Number(participant.score)) ? Number(participant.score) : null
    const bestScore = Math.max(score, ...(existingBest === null ? [] : [existingBest]), ...priorScores)
    const approved = bestScore >= minimumScore
    const now = new Date().toISOString()
    const attempt = {
      id: Date.now(),
      startedAt: now,
      completedAt: now,
      answers: submittedAnswers,
      earnedPoints,
      totalPoints,
      score,
      bestScore,
      minimumScore,
      approved
    }
    const assessmentStatus = approved ? 'approved' : 'failed'
    const updatedParticipant = {
      ...participant,
      attempts: [...attempts, attempt],
      score: bestScore,
      bestScore,
      assessmentStatus,
      status: assessmentStatus === 'failed' ? 'failed' : Number(participant.progress) > 0 ? 'in_progress' : 'pending',
      completedAt: null
    }
    participants[participantIndex] = updatedParticipant
    await saveTrainingArray(client, req, 'trainingParticipants', participants)
    await client.query('COMMIT')
    return res.json({
      attempt,
      participant: updatedParticipant,
      result: {
        score,
        bestScore,
        minimumScore,
        approved,
        earnedPoints,
        totalPoints,
        attemptNumber: attempts.length + 1,
        attemptLimit: Number.isFinite(attemptLimit) ? attemptLimit : null
      }
    })
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {})
    return next(error)
  } finally {
    client.release()
  }
})

router.post('/training-complete', async (req, res, next) => {
  const participantId = req.body?.participantId
  if (participantId === undefined) {
    return res.status(400).json({ message: 'Informe a participação do treinamento.' })
  }
  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    const aliases = await getTrainingEmployeeAliases(client, req)
    if (!aliases.size) {
      await client.query('ROLLBACK')
      return res.status(403).json({ message: 'Não existe funcionário vinculado à sessão.' })
    }
    const participants = await readTrainingArray(client, req.user.companyId, 'trainingParticipants', true)
    const participantIndex = getParticipantIndex(participants, participantId, aliases)
    if (participantIndex < 0) {
      await client.query('ROLLBACK')
      return res.status(404).json({ message: 'Participação não encontrada para o funcionário autenticado.' })
    }
    const participant = participants[participantIndex]
    const trainings = await readTrainingArray(client, req.user.companyId, 'trainings')
    const training = trainings.find((item) => String(item.id) === String(participant.trainingId))
    const contentCount = Array.isArray(training?.contents) ? training.contents.length : 0
    const completedContents = new Set((participant.completedContents || []).map(String))
    if (!training || contentCount === 0 || completedContents.size < contentCount ||
        Number(participant.progress) < 100 || participant.assessmentStatus !== 'approved') {
      await client.query('ROLLBACK')
      return res.status(409).json({ message: 'Conclua todos os conteúdos e obtenha aprovação na avaliação antes de finalizar o treinamento.' })
    }
    const updatedParticipant = {
      ...participant,
      progress: 100,
      status: 'completed',
      completedAt: participant.completedAt || new Date().toISOString()
    }
    participants[participantIndex] = updatedParticipant
    await saveTrainingArray(client, req, 'trainingParticipants', participants)
    await client.query('COMMIT')
    return res.json({ participant: updatedParticipant })
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {})
    return next(error)
  } finally {
    client.release()
  }
})



// Emissão e consulta autenticada de certificados de treinamento.
// O funcionário é sempre derivado da sessão; IDs enviados pelo navegador
// servem apenas para localizar a participação dentro da empresa autenticada.
router.get('/training-certificate', async (req, res, next) => {
  const participantId = req.query?.participantId
  const trainingId = req.query?.trainingId
  if (participantId === undefined || trainingId === undefined) {
    return res.status(400).json({ message: 'Informe a participação e o treinamento.' })
  }

  try {
    const client = await pool.connect()
    try {
      const aliases = await getTrainingEmployeeAliases(client, req)
      if (!aliases.size) {
        return res.status(403).json({ message: 'Não existe funcionário vinculado à sessão.' })
      }

      const participants = await readTrainingArray(client, req.user.companyId, 'trainingParticipants')
      const participant = participants.find((item) =>
        String(item.id) === String(participantId) &&
        String(item.trainingId) === String(trainingId) &&
        participantBelongsToEmployee(item, aliases)
      )
      if (!participant) {
        return res.status(404).json({ message: 'Participação não encontrada para o funcionário autenticado.' })
      }

      const certificates = await readTrainingArray(client, req.user.companyId, 'trainingCertificates')
      const certificate = certificates.find((item) =>
        String(item.participantId) === String(participantId) &&
        String(item.trainingId) === String(trainingId)
      )
      return res.json({ certificate: certificate || null })
    } finally {
      client.release()
    }
  } catch (error) {
    return next(error)
  }
})

router.post('/training-certificate', async (req, res, next) => {
  const participantId = req.body?.participantId
  const trainingId = req.body?.trainingId
  if (participantId === undefined || trainingId === undefined) {
    return res.status(400).json({ message: 'Informe a participação e o treinamento.' })
  }

  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    const aliases = await getTrainingEmployeeAliases(client, req)
    if (!aliases.size) {
      await client.query('ROLLBACK')
      return res.status(403).json({ message: 'Não existe funcionário vinculado à sessão.' })
    }

    const participants = await readTrainingArray(client, req.user.companyId, 'trainingParticipants', true)
    const participant = participants.find((item) =>
      String(item.id) === String(participantId) &&
      String(item.trainingId) === String(trainingId) &&
      participantBelongsToEmployee(item, aliases)
    )
    if (!participant) {
      await client.query('ROLLBACK')
      return res.status(404).json({ message: 'Participação não encontrada para o funcionário autenticado.' })
    }

    const trainings = await readTrainingArray(client, req.user.companyId, 'trainings')
    const training = trainings.find((item) => String(item.id) === String(trainingId))
    if (!training) {
      await client.query('ROLLBACK')
      return res.status(404).json({ message: 'Treinamento não encontrado.' })
    }

    const completedContents = new Set((participant.completedContents || []).map(String))
    const contentCount = Array.isArray(training.contents) ? training.contents.length : 0
    if (
      participant.status !== 'completed' ||
      Number(participant.progress) < 100 ||
      participant.assessmentStatus !== 'approved' ||
      !participant.completedAt ||
      contentCount === 0 ||
      completedContents.size < contentCount
    ) {
      await client.query('ROLLBACK')
      return res.status(409).json({ message: 'O certificado só pode ser emitido após a conclusão de todos os conteúdos e aprovação na avaliação.' })
    }

    const certificates = await readTrainingArray(client, req.user.companyId, 'trainingCertificates', true)
    const existing = certificates.find((item) =>
      String(item.participantId) === String(participantId) &&
      String(item.trainingId) === String(trainingId)
    )
    if (existing) {
      await client.query('COMMIT')
      return res.json({ certificate: existing, alreadyIssued: true })
    }

    const employeeResult = await client.query(
      `SELECT e.id, e.name, e.registration_data
       FROM employees e
       WHERE e.id = $1 AND e.company_id = $2`,
      [req.user.employeeId, req.user.companyId]
    )
    if (!employeeResult.rowCount) {
      await client.query('ROLLBACK')
      return res.status(403).json({ message: 'Funcionário autenticado não encontrado.' })
    }
    const employeeRow = employeeResult.rows[0]
    const employeeName = employeeRow.name ||
      employeeRow.registration_data?.name ||
      participant.employeeName ||
      'Funcionário'
    const issuedAt = new Date().toISOString()
    const certificate = {
      id: `cert-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
      participantId: participant.id,
      employeeId: employeeRow.id,
      employeeName,
      trainingId: training.id,
      trainingName: training.name,
      issuedAt,
      completedAt: participant.completedAt,
      certificateNumber: `CERT-${Date.now()}-${Math.random().toString(10).slice(2, 6).padEnd(4, '0')}`,
      score: participant.score !== null && participant.score !== undefined
        ? Number(participant.score)
        : null,
      workload: Math.max(0, Number(training.duration) || 0)
    }

    await saveTrainingArray(client, req, 'trainingCertificates', [...certificates, certificate])
    await client.query('COMMIT')
    return res.status(201).json({ certificate, alreadyIssued: false })
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {})
    return next(error)
  } finally {
    client.release()
  }
})

export default router
